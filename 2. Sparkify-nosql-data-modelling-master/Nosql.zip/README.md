
In this project a database for storing music and artist records are created. Data is then extracted from the source, transformed using Pandas DataFrame, and loaded into the database.



Procedure:
1. Execute "create_tables.py". This will create a fresh instance of the sparkifydb with empty tables.
2. Execute "etl.py". This will create a csv file with data, and load it into the tables
